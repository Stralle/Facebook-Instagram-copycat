export class PostRequestDTO {
  id: number;
  description: string;
  image: string;
}
