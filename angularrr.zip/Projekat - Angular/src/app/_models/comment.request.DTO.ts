export class CommentRequestDTO {
  id: number;
  content: string;
}
