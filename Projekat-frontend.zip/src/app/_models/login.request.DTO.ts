export class LoginRequestDTO {
  email: string;
  password: string;
}
