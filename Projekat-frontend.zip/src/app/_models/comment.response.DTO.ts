export class CommentDTO {
  id: number;
  username: string;
  content: string;
}
