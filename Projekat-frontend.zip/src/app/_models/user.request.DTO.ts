export class UserRequestDTO {
  id: number;
  email: string;
  username: string;
  password: string;
  imageBase64: string;
}
